#!/usr/bin/env python3
import rospy
import tf
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point, Pose, Quaternion, Vector3
from std_msgs.msg import ColorRGBA
from nav_msgs.msg import OccupancyGrid, Odometry
import numpy as np

class Table2DEnvironment:
    def __init__(self):
        rospy.init_node('table_2d_environment')
        
        # Publisher for visualization
        self.marker_pub = rospy.Publisher('table_marker', Marker, queue_size=10)
        self.map_pub = rospy.Publisher('map', OccupancyGrid, queue_size=10)
        
        # Table parameters
        self.table_width = 0.8  # meters
        self.table_height = 1.2  # meters
        self.table_thickness = 0.05  # meters
        self.table_z_position = 0.45  # Same as Panda gripper height
        
        # Create obstacles
        self.obstacles = [
            {'x': 0.42, 'y': 0.16, 'width': 0.1, 'height': 0.1},
            {'x': 0.6, 'y': -0.18, 'width': 0.1, 'height': 0.1}
        ]
        
        # Create occupancy grid
        self.create_occupancy_grid()
        
        # Publish at 10Hz
        self.timer = rospy.Timer(rospy.Duration(0.1), self.publish_environment)

    def create_occupancy_grid(self):
        self.map = OccupancyGrid()
        self.map.header.frame_id = "panda_link0"
        self.map.info.resolution = 0.02  # 2cm per cell
        self.map.info.width = int(self.table_width / self.map.info.resolution)  # 40
        self.map.info.height = int(self.table_height / self.map.info.resolution)  # 60
        
        # Set origin
        self.map.info.origin.position.x = 0.6 - self.table_width/2  # 0.2
        self.map.info.origin.position.y = -self.table_height/2  # -0.6
        self.map.info.origin.position.z = self.table_z_position
        self.map.info.origin.orientation.w = 1.0
        
        # Initialize empty grid
        self.map.data = [0] * (self.map.info.width * self.map.info.height)
        
        # Add borders as obstacles
        border_width = 2  # 4cm
        for x in range(self.map.info.width):
            for y in range(self.map.info.height):
                if (x < border_width or x >= self.map.info.width - border_width or
                    y < border_width or y >= self.map.info.height - border_width):
                    idx = y * self.map.info.width + x
                    self.map.data[idx] = 100
                
        # Add obstacles with safety margin
        safety_margin = 0.04  # 4cm
        for obs in self.obstacles:
            x_start = int((obs['x'] - self.map.info.origin.position.x - obs['width']/2 - safety_margin) / self.map.info.resolution)
            x_end = int((obs['x'] - self.map.info.origin.position.x + obs['width']/2 + safety_margin) / self.map.info.resolution)
            y_start = int((obs['y'] - self.map.info.origin.position.y - obs['height']/2 - safety_margin) / self.map.info.resolution)
            y_end = int((obs['y'] - self.map.info.origin.position.y + obs['height']/2 + safety_margin) / self.map.info.resolution)
            
            # Debug: Print grid indices
            rospy.loginfo(f"Obstacle at ({obs['x']}, {obs['y']}): x={x_start}:{x_end} ({x_end-x_start} cells), y={y_start}:{y_end} ({y_end-y_start} cells)")
            
            for x in range(x_start, x_end):
                for y in range(y_start, y_end):
                    if 0 <= x < self.map.info.width and 0 <= y < self.map.info.height:
                        idx = y * self.map.info.width + x
                        self.map.data[idx] = 100

    def publish_environment(self, event):
        self.publish_table_marker()
        self.map.header.stamp = rospy.Time.now()
        self.map_pub.publish(self.map)

    def publish_table_marker(self):
        marker = Marker()
        marker.header.frame_id = "panda_link0"
        marker.header.stamp = rospy.Time.now()
        marker.ns = "table"
        marker.id = 0
        marker.type = Marker.CUBE
        marker.action = Marker.ADD
        
        marker.pose.position.x = 0.6
        marker.pose.position.y = 0
        marker.pose.position.z = self.table_z_position - self.table_thickness/2
        marker.pose.orientation.w = 1.0
        
        marker.scale.x = self.table_width
        marker.scale.y = self.table_height
        marker.scale.z = self.table_thickness
        
        marker.color.r = 0.8
        marker.color.g = 0.7
        marker.color.b = 0.6
        marker.color.a = 1.0
        
        self.marker_pub.publish(marker)
        
        for i, obs in enumerate(self.obstacles):
            obstacle_marker = Marker()
            obstacle_marker.header.frame_id = "panda_link0"
            obstacle_marker.header.stamp = rospy.Time.now()
            obstacle_marker.ns = "obstacles"
            obstacle_marker.id = i
            obstacle_marker.type = Marker.CUBE
            obstacle_marker.action = Marker.ADD
            
            obstacle_marker.pose.position.x = obs['x']
            obstacle_marker.pose.position.y = obs['y']
            obstacle_marker.pose.position.z = self.table_z_position + 0.05
            obstacle_marker.pose.orientation.w = 1.0
            
            obstacle_marker.scale.x = obs['width']  # 0.1
            obstacle_marker.scale.y = obs['height']  # 0.1
            obstacle_marker.scale.z = 0.1
            
            obstacle_marker.color.r = 0.9
            obstacle_marker.color.g = 0.1
            obstacle_marker.color.b = 0.1
            obstacle_marker.color.a = 1.0
            
            self.marker_pub.publish(obstacle_marker)

if __name__ == '__main__':
    try:
        env = Table2DEnvironment()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
