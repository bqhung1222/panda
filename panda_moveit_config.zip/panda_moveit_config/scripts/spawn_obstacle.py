#!/usr/bin/env python

import rospy
from gazebo_msgs.srv import SpawnModel
from geometry_msgs.msg import Pose, Point, Quaternion

def spawn_obstacle():
    rospy.init_node('spawn_obstacle_node', anonymous=True)

    sdf_model = """
    <?xml version="1.0" ?>
    <sdf version="1.6">
        <model name="obstacle2">
            <pose>0 0 0 0 0 0</pose>
            <link name="link">
                <collision name="collision">
                    <geometry>
                        <box>
                            <size>0.2 0.2 0.2</size>
                        </box>
                    </geometry>
                </collision>
                <visual name="visual">
                    <geometry>
                        <box>
                            <size>0.2 0.2 0.2</size>
                        </box>
                    </geometry>
                    <material>
                        <diffuse>0 0 1 1</diffuse>
                    </material>
                </visual>
            </link>
        </model>
    </sdf>
    """

    obstacle_pose = Pose()
    obstacle_pose.position = Point(x=0.7, y=0.3, z=0.5)
    obstacle_pose.orientation = Quaternion(x=0.0, y=0.0, z=0.0, w=1.0)

    rospy.wait_for_service('/gazebo/spawn_sdf_model')
    try:
        spawn_model = rospy.ServiceProxy('/gazebo/spawn_sdf_model', SpawnModel)
        spawn_model(model_name="obstacle2",
                    model_xml=sdf_model,
                    robot_namespace="",
                    initial_pose=obstacle_pose,
                    reference_frame="world")
        rospy.loginfo("Successfully spawned obstacle2 at (0.7, 0.3, 0.5)")
    except rospy.ServiceException as e:
        rospy.logerr("Failed to spawn obstacle: %s" % e)

if __name__ == '__main__':
    try:
        spawn_obstacle()
    except rospy.ROSInterruptException:
        pass
