#!/usr/bin/env python3
import rospy
import numpy as np
import moveit_commander
from geometry_msgs.msg import Pose, Point
from math import pi, sqrt
from tf.transformations import quaternion_from_euler

class CustomObstacleAvoidance:
    def __init__(self):
        rospy.init_node('custom_obstacle_avoidance')
        
        # Thiết lập MoveIt cơ bản
        self.move_group = moveit_commander.MoveGroupCommander("panda_arm")
        self.move_group.set_max_velocity_scaling_factor(0.5)  # Giảm tốc độ để chính xác
        
        # Thông số vật cản từ code của bạn
        self.obstacles = [
            {'x': 0.42, 'y': 0.12, 'size': 0.1},
            {'x': 0.6, 'y': -0.15, 'size': 0.1}
        ]
        
        # Kích thước bàn từ code của bạn
        self.table = {'width': 0.8, 'height': 1.2, 'z': 0.45}
        
        # Biên giới an toàn
        self.safety_margin = 0.15
        
        # Thực hiện di chuyển
        self.execute_zigzag()

    def is_position_safe(self, x, y):
        """Kiểm tra vị trí có an toàn không"""
        for obs in self.obstacles:
            distance = sqrt((x - obs['x'])**2 + (y - obs['y'])**2)
            if distance < (obs['size']/2 + self.safety_margin):
                return False
        return True

    def generate_zigzag_points(self):
        """Tạo các điểm di chuyển zig-zag"""
        waypoints = []
        
        # Phạm vi di chuyển dựa trên kích thước bàn của bạn
        x_range = [0.3, 0.8]  # Trước/sau
        y_range = [-0.4, 0.4]  # Trái/phải
        
        # Tạo lưới điểm
        x_steps = np.linspace(x_range[0], x_range[1], 5)
        y_steps = np.linspace(y_range[0], y_range[1], 3)
        
        # Độ cao cố định trên bàn
        z = self.table['z'] + 0.2  # Cao hơn bàn 20cm
        
        # Tạo đường zig-zag
        for i, x in enumerate(x_steps):
            if i % 2 == 0:
                y = y_steps[0]  # Điểm trái
            else:
                y = y_steps[-1]  # Điểm phải
            
            # Hiệu chỉnh nếu gần vật cản
            while not self.is_position_safe(x, y):
                y = y * 0.9  # Dịch chuyển vào giữa
                
            waypoints.append((x, y, z))
        
        return waypoints

    def execute_zigzag(self):
        """Thực hiện di chuyển qua các điểm an toàn"""
        waypoints = self.generate_zigzag_points()
        
        for i, (x, y, z) in enumerate(waypoints):
            rospy.loginfo(f"Di chuyển tới điểm {i+1}: ({x:.2f}, {y:.2f}, {z:.2f})")
            
            # Tạo pose đích
            target_pose = Pose()
            target_pose.position = Point(x, y, z)
            
            # Hướng gripper xuống bàn
            q = quaternion_from_euler(pi, 0, -pi/2)
            target_pose.orientation.x = q[0]
            target_pose.orientation.y = q[1]
            target_pose.orientation.z = q[2]
            target_pose.orientation.w = q[3]
            
            # Di chuyển bằng IK tự động
            self.move_group.set_pose_target(target_pose)
            success = self.move_group.go(wait=True)
            
            if not success:
                rospy.logwarn(f"Không thể di chuyển tới điểm {i+1}")
                # Thử điểm dự phòng
                x_backup = x * 0.95
                y_backup = y * 0.95
                rospy.loginfo(f"Thử điểm dự phòng: ({x_backup:.2f}, {y_backup:.2f}, {z:.2f})")
                target_pose.position = Point(x_backup, y_backup, z)
                self.move_group.set_pose_target(target_pose)
                self.move_group.go(wait=True)
            
            rospy.sleep(0.5)

if __name__ == '__main__':
    try:
        avoidance = CustomObstacleAvoidance()
    except rospy.ROSInterruptException:
        pass