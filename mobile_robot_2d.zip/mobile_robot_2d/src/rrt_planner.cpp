#include <ros/ros.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/geometric/planners/rrt/RRTConnect.h>
#include <ompl/geometric/SimpleSetup.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <geometry_msgs/Pose.h>
#include <nav_msgs/OccupancyGrid.h>
#include <visualization_msgs/Marker.h>
#include <string>
#include <iostream>
#include <sstream>

namespace ob = ompl::base;
namespace og = ompl::geometric;

class RRTPlanner {
public:
  RRTPlanner() : nh_("~"), move_group_(std::make_unique<moveit::planning_interface::MoveGroupInterface>("panda_arm")) {
    map_sub_ = nh_.subscribe("/map", 1, &RRTPlanner::mapCallback, this);
    path_pub_ = nh_.advertise<visualization_msgs::Marker>("/planned_path", 10);
  }

  void mapCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg) {
    if (!map_received_) {
      map_ = *msg;
      map_received_ = true;
      ROS_INFO("Map received: width=%d, height=%d, resolution=%f",
               msg->info.width, msg->info.height, msg->info.resolution);
    }
  }

  bool isMapReceived() const {
    return map_received_;
  }

  moveit::planning_interface::MoveGroupInterface* getMoveGroup() {
    return move_group_.get();
  }

  bool isStateValid(const ob::State* state) {
    if (!map_received_) return false;
    const auto* rv_state = state->as<ob::RealVectorStateSpace::StateType>();
    double x = rv_state->values[0];
    double y = rv_state->values[1];
    int x_idx = static_cast<int>((x - map_.info.origin.position.x) / map_.info.resolution);
    int y_idx = static_cast<int>((y - map_.info.origin.position.y) / map_.info.resolution);
    if (x_idx < 0 || x_idx >= map_.info.width || y_idx < 0 || y_idx >= map_.info.height) return false;
    int idx = y_idx * map_.info.width + x_idx;
    return map_.data[idx] == 0;
  }

  void moveToReadyPose() {
    ROS_INFO("Moving to 'ready' pose");
    move_group_->setNamedTarget("ready");
    bool success = (move_group_->move() == moveit::planning_interface::MoveItErrorCode::SUCCESS);
    if (success) {
      ROS_INFO("Successfully moved to 'ready' pose");
    } else {
      ROS_WARN("Failed to move to 'ready' pose");
    }
  }

  bool planAndExecute(double start_x, double start_y, double goal_x, double goal_y) {
    if (!map_received_) {
      ROS_WARN("Cannot plan: Map not received yet");
      return false;
    }

    // Check if robot state is available
    geometry_msgs::Pose current_pose;
    try {
      current_pose = move_group_->getCurrentPose().pose;
      start_x = current_pose.position.x;
      start_y = current_pose.position.y;
    } catch (const std::exception& e) {
      ROS_WARN("Failed to get current pose: %s. Using default start position (0.5, 0.0)", e.what());
      start_x = 0.5; // Valid default start position
      start_y = 0.0;
    }
    // Ensure start state is within bounds
    double min_x = map_.info.origin.position.x;
    double max_x = map_.info.origin.position.x + map_.info.width * map_.info.resolution;
    double min_y = map_.info.origin.position.y;
    double max_y = map_.info.origin.position.y + map_.info.height * map_.info.resolution;
    start_x = std::max(min_x, std::min(max_x, start_x));
    start_y = std::max(min_y, std::min(max_y, start_y));

    auto space = std::make_shared<ob::RealVectorStateSpace>(2);
    ob::RealVectorBounds bounds(2);
    bounds.setLow(0, min_x);
    bounds.setHigh(0, max_x);
    bounds.setLow(1, min_y);
    bounds.setHigh(1, max_y);
    space->setBounds(bounds);

    auto si = std::make_shared<ob::SpaceInformation>(space);
    si->setStateValidityChecker([this](const ob::State* state) { return isStateValid(state); });

    ob::ScopedState<> start(space);
    start[0] = start_x;
    start[1] = start_y;
    ob::ScopedState<> goal(space);
    goal[0] = goal_x;
    goal[1] = goal_y;

    auto planner = std::make_shared<og::RRTConnect>(si);
    planner->setRange(0.1);

    og::SimpleSetup ss(si);
    ss.setPlanner(planner);
    ss.setStartAndGoalStates(start, goal);

    ob::PlannerStatus solved = ss.solve(5.0);
    if (solved) {
      ROS_INFO("Path found!");
      auto path = ss.getSolutionPath();
      ss.simplifySolution();
      path.interpolate(50);

      visualization_msgs::Marker marker;
      marker.header.frame_id = "panda_link0";
      marker.header.stamp = ros::Time::now();
      marker.ns = "path";
      marker.id = 0;
      marker.type = visualization_msgs::Marker::LINE_STRIP;
      marker.action = visualization_msgs::Marker::ADD;
      marker.scale.x = 0.02;
      marker.color.r = 0.0;
      marker.color.g = 1.0;
      marker.color.b = 0.0;
      marker.color.a = 1.0;

      std::vector<geometry_msgs::Pose> waypoints;
      for (size_t i = 0; i < path.getStateCount(); ++i) {
        const auto* state = path.getState(i)->as<ob::RealVectorStateSpace::StateType>();
        geometry_msgs::Point p;
        p.x = state->values[0];
        p.y = state->values[1];
        p.z = 0.45; // Table height
        marker.points.push_back(p);

        geometry_msgs::Pose pose;
        pose.position.x = state->values[0];
        pose.position.y = state->values[1];
        pose.position.z = 0.45;
        pose.orientation.w = 1.0;
        waypoints.push_back(pose);
      }
      path_pub_.publish(marker);

      moveit_msgs::RobotTrajectory trajectory;
      const double eef_step = 0.01;
      double fraction = move_group_->computeCartesianPath(waypoints, eef_step, 0.0, trajectory);
      if (fraction > 0.9) {
        moveit::planning_interface::MoveGroupInterface::Plan plan;
        plan.trajectory_ = trajectory;
        bool success = (move_group_->execute(plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
        if (success) {
          ROS_INFO("Executed path with %.1f%% completion", fraction * 100);
          return true;
        } else {
          ROS_WARN("Failed to execute path");
          return false;
        }
      } else {
        ROS_WARN("Path execution incomplete: %.1f%%", fraction * 100);
        return false;
      }
    } else {
      ROS_WARN("No path found!");
      return false;
    }
  }

private:
  ros::NodeHandle nh_;
  ros::Subscriber map_sub_;
  ros::Publisher path_pub_;
  std::unique_ptr<moveit::planning_interface::MoveGroupInterface> move_group_;
  nav_msgs::OccupancyGrid map_;
  bool map_received_ = false;
};

int main(int argc, char** argv) {
  ros::init(argc, argv, "rrt_planner");
  RRTPlanner planner;
  ros::Rate rate(10); // 10 Hz

  while (!planner.isMapReceived() && ros::ok()) {
    ROS_INFO_THROTTLE(1, "Waiting for map...");
    ros::spinOnce();
    rate.sleep();
  }

  while (ros::ok()) {
    std::string command;
    std::cout << "Enter '1' to move to 'ready' pose, '2' to plan RRT to goal pose, or '3' to quit: ";
    std::getline(std::cin, command);

    if (command == "1") {
      planner.moveToReadyPose();
    } else if (command == "2") {
      std::cout << "Enter goal pose (x, y) separated by spaces: ";
      std::string input;
      std::getline(std::cin, input);
      std::istringstream iss(input);
      double goal_x, goal_y;
      if (iss >> goal_x >> goal_y) {
        geometry_msgs::Pose current_pose;
        try {
          current_pose = planner.getMoveGroup()->getCurrentPose().pose;
          planner.planAndExecute(current_pose.position.x, current_pose.position.y, goal_x, goal_y);
        } catch (const std::exception& e) {
          ROS_WARN("Failed to get current pose: %s. Using default start position", e.what());
          planner.planAndExecute(0.5, 0.0, goal_x, goal_y); // Valid default start
        }
      } else {
        ROS_WARN("Invalid input. Please enter two numbers separated by spaces.");
      }
    } else if (command == "3") {
      ROS_INFO("Shutting down");
      break;
    } else {
      ROS_WARN("Invalid command. Please enter '1', '2', or '3'.");
    }
    ros::spinOnce();
    rate.sleep();
  }

  return 0;
}